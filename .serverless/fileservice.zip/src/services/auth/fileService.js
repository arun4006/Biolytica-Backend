const path=require('path');

exports.fileUpload = async (req, res) => {
    //res.send("fileupload");
    //res.sendFile(path.join(__dirname +'/index.html'));
    res.send("jsjusju");
}    