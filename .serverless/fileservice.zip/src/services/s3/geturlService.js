const AWS = require("aws-sdk");
const { ENV_BUCKETCONSTANTS } = require("../../constants/env.bucketConstants");
// AWS.config.update({
//     accessKeyId: 'ASIA4Y2YIVR4RZ2K6UP4',
//     secretAccessKey: 'u8TNB57lg5V7Aw0c7A38a1ESgMPkWA6YcyFJqcA9'
//   });
const s3 = new AWS.S3();

exports.handler = async (event, context, callback) => {
  try {
    var params = {
      Bucket: ENV_BUCKETCONSTANTS.bucketName,
    };
    const data = await s3.listObjects(params).promise();
    const filelist = data.Contents.map((obj) => ({
      fileName: obj.Key,
      url: geturl(obj.Key),
    }));

    console.log(filelist);
    const response = {
      "statusCode": 200,
      "headers": {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json",
      },
      "body":JSON.stringify(filelist),
      "isBase64Encoded": false
    };
    callback(null, response);
  } catch (err) {
    console.log(err);
    const errResponse = {
      "statusCode": 500,
      "headers": {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json",
      },
      "body": JSON.stringify({
        message: "An error occurred while uploading the file",
      }),
    };

    callback(err, errResponse);
  }
};

function geturl(filename) {
  var url = s3.getSignedUrl("getObject", {
    Bucket: ENV_BUCKETCONSTANTS.bucketName,
    Key: filename,
  });
  return url;
}
