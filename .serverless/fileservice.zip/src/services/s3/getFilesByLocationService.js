const mysqlConnection = require("../db/mysqlConnection");
const { CognitoJwtVerifier } = require("aws-jwt-verify");
const { ENV_DBCONSTANTS } = require("../../constants/env.dbConstants");
const { ENV_CONSTANTS } = require("../../constants/env.constants");
const {
  ENV_COGNITOCONSTANTS,
} = require("../../constants/env.cognitoConstants");
const util = require("util");
const { ENV_BUCKETCONSTANTS } = require("../../constants/env.bucketConstants");

exports.handler = async (event) => {
 
  try {
    const userName = await getUserTokenInfo(event);
    const userData = await getuserProfileInfo(userName);
    const locationFilesResponse = await getFilesByLocation(userData.userLocation);
    console.log(locationFilesResponse);
    return {
      statusCode: ENV_CONSTANTS.SUCCESS_CODE,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message:ENV_BUCKETCONSTANTS.SUCESSFILE_MSG,
        locationFilesResponse: locationFilesResponse,
      }),
    };
  } catch (err) {
    console.log(err);
    return {
      statusCode: ENV_CONSTANTS.INTERNALSERVER_ERROR,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message: "An error occurred while uploading the files",
      }),
    };
  }
};

const getUserTokenInfo = async (event) => {
  let accessToken = event.headers.Authorization;

  const verifier = CognitoJwtVerifier.create({
    userPoolId: ENV_COGNITOCONSTANTS.USERPOOL_ID,
    tokenUse: ENV_COGNITOCONSTANTS.TOKEN_USE,
    clientId: ENV_COGNITOCONSTANTS.CLIENT_ID,
    scope: ENV_COGNITOCONSTANTS.SCOPE,
  });

  const useraccessToken = accessToken.split(" ")[1];
  try {
    //console.log("token type:" + typeof useraccessToken);
    const userPayload = await verifier.verify(useraccessToken);
    console.log("Token is valid. Payload:", userPayload);
    return userPayload.username;
  } catch (err) {
    console.log(err);
    return "Token is expired";
  }
};

const getuserProfileInfo = async (data) => {
  const query = util.promisify(mysqlConnection.query).bind(mysqlConnection);

  console.log("query:" + query);

  try {
    const getPofileDataByUser = await query(
      `SELECT * FROM ${ENV_DBCONSTANTS.TABLENAME_USERPROFILE} WHERE username = ?`,
      [data]
    );

    console.log("getPofileDataByUser:" + getPofileDataByUser[0].username);
    console.log("type getPofileDataByUser:" + getPofileDataByUser.length);
    //console.log("getPofileDataByUser:" + JSON.stringify(getPofileDataByUser));
    if (getPofileDataByUser.length == 0) {
      return {
        status: "error",
        message: "user Data not found",
      };
    }
    return {
      userLocation: getPofileDataByUser[0].location,
    };
  } catch (err) {
    console.log("error:" + err);
    return err;
  }
};

const getFilesByLocation = async (data) => {
  const query = util.promisify(mysqlConnection.query).bind(mysqlConnection);

  try {
    const getFilesByLocation = await query(
      `SELECT * FROM ${ENV_DBCONSTANTS.TABLENAME_IMAGES} WHERE location = ?`,
      [data]
    );

    console.log("getFilesByLocation:" + getFilesByLocation);
    if (getFilesByLocation.length == 0) {
      return {
        status: "error",
        message: "Data not found",
      };
    }

    return getFilesByLocation;
  } catch (err) {
    console.log("error:" + err);
    return err;
  }
};
