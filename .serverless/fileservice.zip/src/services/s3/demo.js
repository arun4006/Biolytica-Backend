exports.handler = async (event) => {
    try {
      // Parse the request body
      const body = JSON.parse(event.body);
  
      // Loop through the array of files in the body
      for (let i = 0; i < body.files.length; i++) {
        const file = body.files[i];
        
        // Get the file content
        const fileContent = Buffer.from(file.data, 'base64');
        
        // Process the file content here
        console.log(`File ${i+1}: ${file.name}`);
        console.log(fileContent.toString('utf-8'));
      }
  
      return {
        statusCode: 200,
        body: 'Files read successfully'
      };
    } catch (err) {
      console.log(err);
      return {
        statusCode: 500,
        body: 'An error occurred while reading the files'
      };
    }
  };
  