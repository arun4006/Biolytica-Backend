const AWS = require('aws-sdk');

exports.handler = async (event, context) => {
    const s3 = new AWS.S3();
    const bucketName = 'aws-demo-files';
    
    try {
        const s3Objects = await s3.listObjectsV2({ Bucket: bucketName }).promise();

        const images = s3Objects.Contents.filter(object => object.Key.endsWith('.jpg') || object.Key.endsWith('.jpeg') || object.Key.endsWith('.png'));

        const imageUrls = images.map(image => {
            const url = s3.getSignedUrl('getObject', {
                Bucket: bucketName,
                Key: image.Key,
                Expires: 60 * 60 * 24 // URL expiration time in seconds (24 hours in this case)
            });
            return url;
        });

        return {
            statusCode: 200,
            body: JSON.stringify(imageUrls)
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Error retrieving images from S3' })
        };
    }
};
