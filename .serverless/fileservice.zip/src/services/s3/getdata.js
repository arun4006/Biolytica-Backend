const AWS = require('aws-sdk');
const s3 = new AWS.S3();

// Set your S3 access key ID and secret access key as environment variables or constants
const accessKeyId = 'ASIA4Y2YIVR423GELGKM';
const secretAccessKey = 'cu093lRmGulWNOa4d9dStjTZW+cH6j7sY4bfLDo0';

// Configure the AWS SDK with your S3 credentials
AWS.config.update({
  accessKeyId: accessKeyId,
  secretAccessKey: secretAccessKey
});

exports.handler = async (event) => {
  try {
    const bucketName = 'aws-demo-files';
    const objects = await s3.listObjects({ Bucket: bucketName }).promise();
    const response = {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type'
      },
      body: JSON.stringify(objects.Contents)
    };
    return response;
  } catch (err) {
    console.error(err);
    const response = {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal server error' })
    };
    return response;
  }
};
