const multer = require('multer');
const upload = multer();

exports.handler = async (event) => {
  const formData = JSON.parse(event.body);
  
  try {
    const files = formData.files;
    console.log(files);
    // process or upload the files as needed
  
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'File(s) uploaded successfully' })
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error uploading file(s)' })
    };
  }
};
