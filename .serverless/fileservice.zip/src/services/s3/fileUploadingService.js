const jwt = require("jsonwebtoken");
const { CognitoJwtVerifier } = require("aws-jwt-verify");
const {
  ENV_COGNITOCONSTANTS,
} = require("../../constants/env.cognitoConstants");
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { ENV_BUCKETCONSTANTS } = require("../../constants/env.bucketConstants");
const s3Client = new S3Client({ region: ENV_BUCKETCONSTANTS.AWS_REGION });



exports.handler = async (event) => {

  

  let accessToken = event.headers.Authorization;

  const verifier = CognitoJwtVerifier.create({
    userPoolId: ENV_COGNITOCONSTANTS.USERPOOL_ID,
    tokenUse: ENV_COGNITOCONSTANTS.TOKEN_USE,
    clientId: ENV_COGNITOCONSTANTS.CLIENT_ID,
    scope: ENV_COGNITOCONSTANTS.SCOPE,
  });

 

  try {

    

    console.log("req Token is :", accessToken);
    const useraccessToken = accessToken.split(" ")[1];
    const userPayload = await verifier.verify(useraccessToken);
    console.log("Token is valid. Payload:", userPayload);

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Token decoded successfully",
        data: userPayload,
        // token: accessToken,
      }),
    };
  } catch (error) {
    console.log(error);
    return {
      statusCode: 400,
      body: JSON.stringify({ message: "Invalid token" }),
    };
  }
};


function parseMultipartFormData(body) {
  const boundary = body.match(/boundary=(?:"([^"]+)"|([^;]+))/i)[1];
  const parts = body.split(new RegExp(`--${boundary}`));

  // Remove first and last element (empty)
  parts.shift();
  parts.pop();

  // Extract file name and content for each part
  return parts.map(part => {
    const [, nameMatch] = part.match(/name="(.*)"/i);
    const name = nameMatch || '';
    const content = part.split('\r\n\r\n')[1].trim();
    return { name, content };
  });
}