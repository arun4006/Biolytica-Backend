const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');

const s3Client = new S3Client({ region: 'us-east-1' }); // Replace with your bucket region

exports.handler = async (event) => {
  const fileContent = Buffer.from(event.body, 'base64');
  const bucketName = 'aws-demo-files'; // Replace with your bucket name
  const objectKey = Date.now()+'.png' // Unique object key
  const params = {
    Bucket: bucketName,
    Key: objectKey,
    Body: fileContent
  };

  try {
    const result = await s3Client.send(new PutObjectCommand(params));
    console.log(`File uploaded successfully to ${result.Location}`);
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*', // Allow all origins to access the resource
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: 'File uploaded successfully',
        url: event
      })
    };
  } catch (err) {
    console.log(err);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*', // Allow all origins to access the resource
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: 'An error occurred while uploading the file'
      })
    };
  }
};
