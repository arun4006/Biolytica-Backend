 const ENV_COGNITOCONSTANTS = {
    CLIENT_ID: "5js45754cce2otm1jhjfpt0nlq",
    CLIENT_SECRET:"ujq2jt1dorto9m7dgf9af2amo4853o6ur6i2qs2q1ri5ms7hl5m",
    COGNITO_DOMAIN:"blogpost",
    REDIRECT_URI:"http://localhost:5500/api-auth/auth",
    USERPOOL_ID:"us-east-1_J2h9TpnHe",
    AWS_REGION: 'us-east-1'
};

module.exports= { ENV_COGNITOCONSTANTS };