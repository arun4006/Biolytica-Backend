 const ENV_COGNITOCONSTANTS = {
    CLIENT_ID: "2drb2nt3dpp9kcspoq52onadn3",
    COGNITO_DOMAIN:"cognitive_test",
    USERPOOL_ID:"us-east-1_xD0JFohTE",
    AWS_REGION: 'us-east-1',
    TOKEN_USE:'access',
    USERREG_MSG:"user Registered successfully"
};

module.exports= { ENV_COGNITOCONSTANTS };