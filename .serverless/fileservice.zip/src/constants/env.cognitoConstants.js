 const ENV_COGNITOCONSTANTS = {
    CLIENT_ID: "5js45754cce2otm1jhjfpt0nlq",
    CLIENT_SECRET:"ujq2jt1dorto9m7dgf9af2amo4853o6ur6i2qs2q1ri5ms7hl5m",
    COGNITO_DOMAIN:"blogpost",
    REDIRECT_URI:"http://localhost:5500/api-auth/auth"
};

module.exports= { ENV_COGNITOCONSTANTS };