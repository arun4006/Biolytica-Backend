 const ENV_COGNITOCONSTANTS = {
    CLIENT_ID: "54js58dob1gqfutsfkt90oupac",
    CLIENT_SECRET:"1tj394jdtil730p6uft9a92lemd9945n800e0ks8453g0m8qr31b",
    COGNITO_DOMAIN:"cognitity",
    REDIRECT_URI:"http://localhost:5500/api-auth/auth",
    USERPOOL_ID:"us-east-1_oXI1bfGdw",
    AWS_REGION: 'us-east-1',
    SCOPE:'profile',
    TOKEN_USE:'access'
};

module.exports= { ENV_COGNITOCONSTANTS };