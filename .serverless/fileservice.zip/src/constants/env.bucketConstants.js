const ENV_BUCKETCONSTANTS = {
  AWS_REGION: 'us-east-1',
  SIGNATURE_VERSION: "v4",
  ENCODED_TYPE: 'base64',
  FILE_UPLOAD: "file Uploaded",
  ERROR_FROM_S3BUCKET: "Error retrieving files from S3 bucket",
  AccessKeyId:'ASIA4Y2YIVR4T2DREXUZ',
  secretAccessKey: 'xn21IWyzPQld9hWw5USliD+qfj/WnYCrWSgkART6',
  bucketName:'aws-demo-files'
};

module.exports =  ENV_BUCKETCONSTANTS ;
