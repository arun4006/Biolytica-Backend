const ENV_DBCONSTANTS = {
  HOST: 'localhost',
  USER: 'root',
  PASSWORD:'123456',
  DATABASE: 'bucket',
  TABLENAME_IMAGES:'images'
  };
  
module.exports= {ENV_DBCONSTANTS};