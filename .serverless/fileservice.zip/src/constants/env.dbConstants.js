const ENV_DBCONSTANTS = {
  HOST: 'database-3.cdgkfoacvf6u.us-east-1.rds.amazonaws.com',
  USER: 'admin',
  PASSWORD:'qwerty1234',
  DATABASE: 'my_db',
  TABLENAME_IMAGES:'Imageinfo',
  TABLENAME_USERPROFILE:'UserProfile',
  PORT:'3306'
  };
  
module.exports= {ENV_DBCONSTANTS};