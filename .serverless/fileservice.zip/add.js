
const { CognitoJwtVerifier } = require('aws-jwt-verify');

async function add()
{
    const verifier = CognitoJwtVerifier.create({
        userPoolId: 'us-east-1_oXI1bfGdw',
        tokenUse: 'access',
        clientId: '54js58dob1gqfutsfkt90oupac',
        scope: "profile"
      });
      
    const token='eyJraWQiOiJmN2k3ZGNJR3VwS1FOdEFrN0pYajl4TUhPU0tENThiOXJFdXZNaXNlOXBRPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJiMzI4Y2ExYi1lZTRmLTRjZjMtOTZhZi1kNmZkYWNlYzA1MDEiLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9vWEkxYmZHZHciLCJ2ZXJzaW9uIjoyLCJjbGllbnRfaWQiOiI1NGpzNThkb2IxZ3FmdXRzZmt0OTBvdXBhYyIsIm9yaWdpbl9qdGkiOiJjN2FiNWIxMC03NjVlLTQwZGItOTRlNS1mOTk5YzU5ODEyYjkiLCJldmVudF9pZCI6IjUyMTQyY2M2LTY4OWUtNDQwNS04ZDc2LTc2MGQ3YmM4Nzk1ZiIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwiLCJhdXRoX3RpbWUiOjE2ODM3MDgwOTAsImV4cCI6MTY4MzcxMTY5MCwiaWF0IjoxNjgzNzA4MDkwLCJqdGkiOiI4Mjg3YTA0Yy1lYmM3LTRmMWMtYWM2ZC05ZWNmNmZlY2NmMGEiLCJ1c2VybmFtZSI6ImIzMjhjYTFiLWVlNGYtNGNmMy05NmFmLWQ2ZmRhY2VjMDUwMSJ9.Nzgv-e3oC-c-6pUXYqFU6N2L_hlOVBm7sHBYHlug3f_baOuk0FhbWuASFi6V3f7O7VoVyJ2R21k3cBJLyzmFiAb8bktKTFZsih4nJc4MhSWHTgYOlHdQWMI1vbTql-63_kFH1s27-tX_7Gb17IOKn-oODMcEVgjld4gKNVwQCPsWgd6CbXOXoOlrMKMVyBah7BjY96PVM8wS0-jSs2I7Niwc4XUhQHt0Crq0J5LMshYDGLGXvFnVqFnO-i8yAQVrDrtcn-fRmiAqF3Bh6lJLVn0jTDG4OjgTqD4Vri2ZGfWR-F6Z7l9XuvroG5KsXwiK3naNppBLTuSofRzN84Nd4Q';
    const payload = await verifier.verify(
         token
      );
     console.log('Token is valid. Payload:', payload);
//   } catch (error) {
//     console.log('Token not valid!', error);
 // }

}

add();