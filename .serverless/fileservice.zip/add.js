
const { CognitoJwtVerifier } = require('aws-jwt-verify');

async function add()
{
    const verifier = CognitoJwtVerifier.create({
        userPoolId: 'us-east-1_oXI1bfGdw',
        tokenUse: 'access',
        clientId: '54js58dob1gqfutsfkt90oupac',
        scope: "profile"
      });
      
    const token='eyJraWQiOiJmN2k3ZGNJR3VwS1FOdEFrN0pYajl4TUhPU0tENThiOXJFdXZNaXNlOXBRPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJiMzI4Y2ExYi1lZTRmLTRjZjMtOTZhZi1kNmZkYWNlYzA1MDEiLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9vWEkxYmZHZHciLCJ2ZXJzaW9uIjoyLCJjbGllbnRfaWQiOiI1NGpzNThkb2IxZ3FmdXRzZmt0OTBvdXBhYyIsIm9yaWdpbl9qdGkiOiI2M2U3NjBmYy0xNjQzLTQxNTMtYjRlZS05MGVkN2JiYjg5NmMiLCJ0b2tlbl91c2UiOiJhY2Nlc3MiLCJzY29wZSI6Im9wZW5pZCBwcm9maWxlIGVtYWlsIiwiYXV0aF90aW1lIjoxNjgzODAyOTU4LCJleHAiOjE2ODM4MDY1NTgsImlhdCI6MTY4MzgwMjk1OCwianRpIjoiZTk1NDcxOTUtOTBlZS00ZTFiLWFmMzEtNDhiMWMyZWM1OGI3IiwidXNlcm5hbWUiOiJiMzI4Y2ExYi1lZTRmLTRjZjMtOTZhZi1kNmZkYWNlYzA1MDEifQ.plnhMmvaMJmjNdcxIXkj922OOx42Zw-CU29Yi2Mbb7GNo0oj7mrjXbrk2g9OPbWVJS_QHEfizlt1G9Td5ZBXZitPKsUj-zixt2B2E1wxewv0xpl1kaQnZ-QcuEICPSp7n6wxJxkxZYvfLk_DvKXZhobTItOl8PM1Z_WzNOAIZDhoE7Z0IXz7Ro1r1hH5T-DArlsay4DahhRdVzLJtXRd6C7KOF5tjQ92PJE--EBnp1DicGutk1ZRzRZydIsxCSrBAW_jSlxGOuE_ibzbvs9kura7DKUbOjmUNWDl8xbsEiXdR9Ro8yEYzlBdG5ALta20fIOSJt6xz1NTr6fKbwvjvQ';
         const payload = await verifier.verify(
         token
      );
     console.log('Token is valid. Payload:', payload);
//   } catch (error) {
//     console.log('Token not valid!', error);
 // }

}

add();