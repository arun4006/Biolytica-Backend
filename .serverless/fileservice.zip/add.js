
const { CognitoJwtVerifier } = require('aws-jwt-verify');

async function add()
{
    const verifier = CognitoJwtVerifier.create({
        userPoolId: 'us-east-1_oXI1bfGdw',
        tokenUse: 'access',
        clientId: '54js58dob1gqfutsfkt90oupac',
        scope: "profile"
      });
      
    const token='eyJraWQiOiJmN2k3ZGNJR3VwS1FOdEFrN0pYajl4TUhPU0tENThiOXJFdXZNaXNlOXBRPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJiMzI4Y2ExYi1lZTRmLTRjZjMtOTZhZi1kNmZkYWNlYzA1MDEiLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9vWEkxYmZHZHciLCJ2ZXJzaW9uIjoyLCJjbGllbnRfaWQiOiI1NGpzNThkb2IxZ3FmdXRzZmt0OTBvdXBhYyIsIm9yaWdpbl9qdGkiOiI3Y2NjYWZhZC1hZDkxLTQ1YWUtOWQyMi1mYjJjOGJhODJlZDEiLCJldmVudF9pZCI6IjcxNzdjZmEzLWM3NzEtNGFlNC04ZjIwLWU2ZWU0OTA1NzVlNSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwiLCJhdXRoX3RpbWUiOjE2ODM2MjExMTIsImV4cCI6MTY4MzYyNDcxMiwiaWF0IjoxNjgzNjIxMTEzLCJqdGkiOiI5ZDZmYzNiYS1jOWYzLTRhMWMtODM5Yi1mODQyZjBhMzhmZGQiLCJ1c2VybmFtZSI6ImIzMjhjYTFiLWVlNGYtNGNmMy05NmFmLWQ2ZmRhY2VjMDUwMSJ9.iMkwYbghgT-AhNZsUWlMzeOFlxXxkiAOaDjHcYFQjHJ08fRpScpQu_krmo5j2K9v_PHWevA8D-vohi-J0_Y_2UUi4C5mDZFaHfvARiB67Z2-cbyYswrWMsd5kMhybc4gfvmVfbnNubuEBjWXxtCapGwkdi68YKY85Jddfy6y6_gGzJE52oGjLGbbI-UN4X_uV1kis8Tig2qZAQ0cuPjNrXEBFfMYTD99kJb8vTp0Oy5LB06M3ns7KeyVR657Z0WgBKa77PRaUVVuLDrXcSJOZ5hFaBjWsgVqCRyDas6tilgjfyxVCfcdF9cSQERz1Gr3F5rfRbz0aAQhIzWDdGLzEg';

  
    const payload = await verifier.verify(
         token
      );
     console.log('Token is valid. Payload:', payload);
//   } catch (error) {
//     console.log('Token not valid!', error);
 // }

}

add();