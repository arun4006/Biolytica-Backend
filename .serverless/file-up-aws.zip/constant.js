export const region='us-east-1';
export const signatureVersion= 'v4';
export const encodedType='base64';
export const fileUploaded= 'file Uploaded';
export const errorFromS3Bukcet='Error retrieving files from S3 bucket';
export const successCode=200;
export const internalServerError=500;
